package com.example.muslimday

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, AdhanScheduler.names.lastIndex)
        val nm = ctx.getSystemService(NotificationManager::class.java)

        val ch = NotificationChannel("adhan_v1", "الأذان", NotificationManager.IMPORTANCE_HIGH)
        // ضع ملف الأذان في app/src/main/res/raw/adhan.mp3 ليُشغَّل مع الإشعار
        val soundId = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName)
        if (soundId != 0) {
            ch.setSound(
                Uri.parse("android.resource://${ctx.packageName}/$soundId"),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        nm.createNotificationChannel(ch)

        val open = PendingIntent.getActivity(
            ctx, 100, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, "adhan_v1")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("حان الآن موعد صلاة ${AdhanScheduler.names[idx]}")
            .setContentText("حيّ على الصلاة")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(idx, n)

        AdhanScheduler.scheduleAll(ctx)
    }
}
