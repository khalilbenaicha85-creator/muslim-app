package com.example.muslimday

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AdhanScheduler {
    val names = arrayOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")

    /** يجدولي أقرب أذان قادم لكل صلاة من الخمس. */
    fun scheduleAll(ctx: Context) {
        val p = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
        val lat = p.getString("lat", "21.4225")!!.toDouble()
        val lng = p.getString("lng", "39.8262")!!.toDouble()
        val method = PrayerTimes.methods[p.getInt("method", 0).coerceIn(0, PrayerTimes.methods.lastIndex)]
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()

        for (i in intArrayOf(0, 2, 3, 4, 5)) {
            var next = -1L
            for (shift in 0..2) {
                val c = Calendar.getInstance()
                c.add(Calendar.DAY_OF_YEAR, shift)
                val t = PrayerTimes.millis(
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
                    lat, lng, method
                )[i]
                if (t > now) { next = t; break }
            }
            if (next < 0) continue

            val pi = PendingIntent.getBroadcast(
                ctx, i,
                Intent(ctx, AdhanReceiver::class.java).putExtra("idx", i),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            }
        }
    }
}
