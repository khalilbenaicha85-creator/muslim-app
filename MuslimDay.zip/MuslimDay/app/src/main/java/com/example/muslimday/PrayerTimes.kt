package com.example.muslimday

import kotlin.math.*

/** حساب مواقيت الصلاة فلكياً (بدون إنترنت). */
object PrayerTimes {
    class Method(val name: String, val fajr: Double, val isha: Double, val ishaMinutes: Int = 0)

    val methods = listOf(
        Method("رابطة العالم الإسلامي", 18.0, 17.0),
        Method("أم القرى (مكة)", 18.5, 0.0, 90),
        Method("الهيئة المصرية", 19.5, 17.5),
        Method("جامعة العلوم - كراتشي", 18.0, 18.0),
        Method("أمريكا الشمالية", 15.0, 15.0)
    )

    private fun fix(a: Double, b: Double) = a - b * floor(a / b)
    private fun sinD(d: Double) = sin(Math.toRadians(d))
    private fun cosD(d: Double) = cos(Math.toRadians(d))
    private fun tanD(d: Double) = tan(Math.toRadians(d))

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** returns [declination (deg), equation of time (hours)] */
    private fun sun(jd: Double): DoubleArray {
        val d = jd - 2451545.0
        val g = fix(357.529 + 0.98560028 * d, 360.0)
        val q = fix(280.459 + 0.98564736 * d, 360.0)
        val l = fix(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g), 360.0)
        val e = 23.439 - 0.00000036 * d
        val ra = fix(Math.toDegrees(atan2(cosD(e) * sinD(l), cosD(l))) / 15.0, 24.0)
        val decl = Math.toDegrees(asin(sinD(e) * sinD(l)))
        return doubleArrayOf(decl, q / 15.0 - ra)
    }

    /**
     * يرجع 6 أوقات بالميلي ثانية (UTC epoch):
     * الفجر، الشروق، الظهر، العصر، المغرب، العشاء. القيمة -1 إذا تعذر الحساب.
     */
    fun millis(y: Int, m: Int, d: Int, lat: Double, lng: Double, method: Method): LongArray {
        val jd = julian(y, m, d) - lng / 360.0

        fun midDay(t: Double) = fix(12 - sun(jd + t)[1], 24.0)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t)[0]
            val x = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
            if (x < -1 || x > 1) return Double.NaN
            val h = Math.toDegrees(acos(x)) / 15.0
            return midDay(t) + if (ccw) -h else h
        }

        fun asr(t: Double): Double {
            val decl = sun(jd + t)[0]
            val angle = -Math.toDegrees(atan(1.0 / (1.0 + tanD(abs(lat - decl)))))
            return angleTime(angle, t, false)
        }

        var raw = doubleArrayOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0)
        repeat(2) {
            val t = DoubleArray(6) { i -> raw[i] / 24.0 }
            raw = doubleArrayOf(
                angleTime(method.fajr, t[0], true),
                angleTime(0.833, t[1], true),
                midDay(t[2]),
                asr(t[3]),
                angleTime(0.833, t[4], false),
                angleTime(method.isha, t[5], false)
            )
        }
        if (method.ishaMinutes > 0) raw[5] = raw[4] + method.ishaMinutes / 60.0

        val utc = java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"))
        utc.clear()
        utc.set(y, m - 1, d, 0, 0, 0)
        val base = utc.timeInMillis
        return LongArray(6) { i ->
            if (raw[i].isNaN()) -1L else base + ((raw[i] - lng / 15.0) * 3600000.0).toLong()
        }
    }
}
