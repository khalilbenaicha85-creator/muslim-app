package com.example.muslimday

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var body: LinearLayout
    private var tab = 0
    private val green = Color.parseColor("#1B6B4A")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rowParams() = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }

    private fun card(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(14).toFloat()
    }

    private fun label(text: String, size: Float, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(Color.parseColor("#1F2A24"))
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, 0, 0, dp(10))
        return tv
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.parseColor("#F5F3EC"))

        val tabs = LinearLayout(this)
        tabs.setBackgroundColor(green)
        listOf("المواقيت", "الصباح", "المساء", "بعد الصلاة").forEachIndexed { i, t ->
            val tv = TextView(this)
            tv.text = t
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            tv.setPadding(0, dp(16), 0, dp(16))
            tv.setOnClickListener { show(i) }
            tabs.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(16), dp(16), dp(16))
        val scroll = ScrollView(this)
        scroll.addView(body)

        root.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        AdhanScheduler.scheduleAll(this)
        show(0)
        requestPerms()
    }

    private fun show(i: Int) {
        tab = i
        body.removeAllViews()
        when (i) {
            0 -> showTimes()
            1 -> showAzkar(Azkar.morning, "أذكار الصباح")
            2 -> showAzkar(Azkar.evening, "أذكار المساء")
            else -> showAzkar(Azkar.afterPrayer, "أذكار بعد الصلاة")
        }
    }

    private fun showTimes() {
        val lat = prefs.getString("lat", "21.4225")!!.toDouble()
        val lng = prefs.getString("lng", "39.8262")!!.toDouble()
        val mi = prefs.getInt("method", 0).coerceIn(0, PrayerTimes.methods.lastIndex)
        val c = Calendar.getInstance()
        val times = PrayerTimes.millis(
            c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
            lat, lng, PrayerTimes.methods[mi]
        )
        val now = System.currentTimeMillis()
        val next = times.indices.firstOrNull { times[it] > now }

        body.addView(label(SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar")).format(c.time), 18f, true))
        body.addView(
            label(
                if (prefs.contains("lat")) "حسب موقعك الحالي" else "الموقع الافتراضي: مكة المكرمة (اسمح بالوصول للموقع)",
                13f, false
            )
        )

        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, PrayerTimes.methods.map { it.name })
        sp.setSelection(mi)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != prefs.getInt("method", 0)) {
                    prefs.edit().putInt("method", pos).apply()
                    AdhanScheduler.scheduleAll(this@MainActivity)
                    show(0)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        body.addView(sp, rowParams())

        val fmt = SimpleDateFormat("hh:mm a", Locale("ar"))
        times.forEachIndexed { i, t ->
            val row = LinearLayout(this)
            row.setPadding(dp(16), dp(14), dp(16), dp(14))
            row.background = card(if (i == next) Color.parseColor("#CDEBDD") else Color.WHITE)
            val n = TextView(this)
            n.text = AdhanScheduler.names[i]
            n.textSize = 20f
            val tm = TextView(this)
            tm.text = if (t < 0) "--:--" else fmt.format(Date(t))
            tm.textSize = 20f
            row.addView(n, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tm)
            body.addView(row, rowParams())
        }

        val refresh = Button(this)
        refresh.text = "تحديث الموقع"
        refresh.setOnClickListener { updateLocation() }
        body.addView(refresh, rowParams())

        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            val b = Button(this)
            b.text = "السماح بالتنبيه الدقيق للأذان"
            b.setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
            body.addView(b, rowParams())
        }
    }

    private fun showAzkar(list: List<Azkar.Zikr>, title: String) {
        body.addView(label(title, 20f, true))
        for (z in list) {
            var left = z.count
            val tv = TextView(this)
            tv.textSize = 19f
            tv.setLineSpacing(0f, 1.3f)
            tv.setTextColor(Color.parseColor("#1F2A24"))
            tv.setPadding(dp(16), dp(16), dp(16), dp(16))
            tv.background = card(Color.WHITE)
            fun refresh() {
                tv.text = z.text + "\n\n" + (if (left > 0) "المتبقي: $left  (اضغط للعد)" else "✓ تم")
                tv.alpha = if (left > 0) 1f else 0.5f
            }
            refresh()
            tv.setOnClickListener { if (left > 0) { left--; refresh() } }
            body.addView(tv, rowParams())
        }
    }

    // ---------- الصلاحيات والموقع ----------
    private fun requestPerms() {
        val need = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else updateLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateLocation()
    }

    private fun saveLoc(l: Location) {
        prefs.edit().putString("lat", l.latitude.toString()).putString("lng", l.longitude.toString()).apply()
        AdhanScheduler.scheduleAll(this)
        if (tab == 0) show(0)
    }

    private fun updateLocation() {
        val ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            val providers = lm.getProviders(true)
            val last = providers.mapNotNull {
                try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null }
            }.maxByOrNull { it.time }
            if (last != null) { saveLoc(last); return }
            val prov = providers.firstOrNull { it != LocationManager.PASSIVE_PROVIDER } ?: return
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(l: Location) { saveLoc(l) }
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }, Looper.getMainLooper())
        } catch (e: SecurityException) {
        }
    }
}
