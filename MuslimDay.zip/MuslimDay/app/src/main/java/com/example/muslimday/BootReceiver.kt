package com.example.muslimday

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AdhanScheduler.scheduleAll(ctx)
    }
}
